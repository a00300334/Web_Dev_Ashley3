<?php

$counter = 0;

while($counter <= 100)
{
    $couter ++;
    echo "Counter is {$counter}";
}

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

