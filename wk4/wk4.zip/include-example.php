<?php

//include 

// include once


//Pass control to another PHP (in same dir)
//if ($is_valid) {  
//	include('hi.php');  
//	exit();
//}

//include('view/header.php’);	//down one directory
//include('./error.php’);		//in the current directory	
//include('../error.php’);		//up one directory
//include('../../error.php’);		//up two directories


include('hi.php');  

/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

