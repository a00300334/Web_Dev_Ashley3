<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1> Today praticed files </h1>
        
        <ul>
              <li> <a href="ex1/prodCalc.php"> Excersise -1 product discout calc</a> </li>
            <li> <a href="while_loop.php"> while_loops </a> </li>
             <li> <a href="include-example.php"> include - example</a> </li>
        </ul>
        <?php
        // put your code here
      
        ?>
     
    </body>
</html>
